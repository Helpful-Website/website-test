<?php session_start(); ?>
<?php include "footer/footer.php" ?>
<?php include "index.php" ?>

<!DOCTYPE html>
<html lang="hy">
<head>
    <meta charset="UTF-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <meta name="description" content="This is helpful website. Here you will find only reliable and interesting news. There aren't some falsehoods in the 'HELPFUL' media website. It's interesting with us."/>
    <meta name="generator" content="WordPress 6.4.3"/>
    <meta name="keywords" content="news, online radio, live news, radio, live chat, live radio."/>
    <meta name="author" content="Helpful.am"/>
    <link rel="icon" type="image/x-icon" href="/helpful/icon.ico"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>
    <title><?php echo "HELPFUL - Լրատվական" ?></title>
    <style><?php include 'style.css'; ?></style>
</head>

    <body>
        <section>   
            <div class="parent">
                <div class="child">
                    <a href="header.php"><img src="images/helpful.png" alt="Helpful Logo" width="100" height="65"/></a>
                    <div class="marquee-container">
                        <div class="marquee-text" id="text-stop"><?php echo ""; ?></div>
                        <span class="play" id="start"><i class="fas fa-play" style="color: #0050cb"></i></span>
                        <span class="pause" id="stop"><i class="fa-solid fa-pause" style="color: #0050cb"></i></span>
                    </div>
                        <div class="box">
                            <p><span class="weather"><?php echo "Երևան"; ?></span></p>
                            <div class="clock" id="time"></div>
                        </div>
                    <nav class="menu">
                        <ul class="menu-items">
                            <li><a class="burger-menu" href="header.php"><span></span></a></li>
                            <li><a href="header.php"><?php echo "Քաղաքականություն"; ?></a></li>
                            <li><a href="header.php"><?php echo "Տնտեսություն"; ?></a></li>
                            <li><a href="header.php"><?php echo "Մշակույթ"; ?></a></li>
                            <li><a href="header.php"><?php echo "Ուղիղ եթեր"; ?></a></li>
                            <li><a href="header.php"><?php echo "Գովազդի համար"; ?></a></li>
                            <li><a class="active" href="header.php"><?php echo "Բաժանորդագրվել"; ?></a></li>
                            <li><a href="header.php"><?php echo "Որոնում"; ?></a></li>
                        </ul>
                    </nav> 
                </div>
            </div>
        </section>

        <script src="javascript/marquee.js" type="text/javascript"></script>
        <script src="javascript/time.js" type="text/javascript"></script>
    </body>
</html>