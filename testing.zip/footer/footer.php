<?php ?>

<link rel="icon" type="image/x-icon" href="/helpful/icon.ico"/>

<footer>
    
</footer>